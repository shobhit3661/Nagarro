package com.nagarro.Assignment3.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nagarro.Assignment3.dao.ProductDao;
import com.nagarro.Assignment3.model.Product;

/**
 * Servlet implementation class DeleteProduct
 */
@WebServlet("/DeleteProduct")
public class DeleteProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String productId = request.getParameter("Product");
		ProductDao.deleteProduct(productId);
		String msg = "Product is Deleted";
		request.setAttribute("msg", msg);
		List<Product> result = ProductDao.getProductList(request, response);
		request.setAttribute("result", result);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Products.jsp");
		dispatcher.forward(request, response);
	}

}
