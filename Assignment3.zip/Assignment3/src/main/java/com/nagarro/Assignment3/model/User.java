package com.nagarro.Assignment3.model;


import java.util.List;
import javax.persistence.*;

//import org.hibernate.Session;
//
//import com.nagarro.Assignment3.Hibernate.HibernateUtil;

@Entity
@Table(name = "users")
public class User {
	@Id @GeneratedValue
	int id ;
	@Column(name="username", unique=true)
	String userName ;
	String Pass ;
	
	@OneToMany(mappedBy="user", cascade= CascadeType.MERGE, fetch=FetchType.EAGER)
	List<Product> productList ;
	
	public int getId() {
		return id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPass() {
		return Pass;
	}
	public void setPass(String pass) {
		Pass = pass;
	}

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", Pass=" + Pass + "]";
	}
	
}
