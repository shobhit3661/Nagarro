package com.nagarro.Assignment3.servlet;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;

import com.nagarro.Assignment3.model.Product;
import com.nagarro.Assignment3.model.User;
import com.nagarro.Assignment3.Hibernate.HibernateUtil;
import com.nagarro.Assignment3.dao.ProductDao;;

/**
 * Servlet implementation class LoginPage
 */
//@WebServlet("/LoginPage")
public class LoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("came to Validate User");
		String userName = request.getParameter("username");
		String pass = request.getParameter("password");
		Session session = HibernateUtil.sf.openSession();
		session.beginTransaction();
		User user = (User) session.createQuery("FROM User WHERE userName = :username").setParameter("username", userName)
				.uniqueResult();
		session.getTransaction().commit();
		session.close();
		if (user==null)
		{
			System.out.println("No such User");
			String msg = "No such User Exists";
			request.setAttribute("msg", msg);
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
			dispatcher.forward(request, response);
		}
		else if(user.getPass().equals(pass))
		{
			Boolean find = true;
			request.setAttribute("find", find);
			HttpSession sessionuser =request.getSession();  
			sessionuser.setAttribute("userName",userName); 
			List<Product> result = ProductDao.getProductList(request, response);
			request.setAttribute("result", result);
			RequestDispatcher dispatcher = request.getRequestDispatcher("Products.jsp");
			dispatcher.forward(request, response);
		}
		else
		{
			System.out.println("Worng pass");
			String msg = "Password incorrect enter Again";
			request.setAttribute("msg", msg);
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
			dispatcher.forward(request, response);
		}
		
	}

}
