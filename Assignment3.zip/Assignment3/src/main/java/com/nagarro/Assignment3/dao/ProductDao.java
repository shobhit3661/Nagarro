package com.nagarro.Assignment3.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;

import com.nagarro.Assignment3.Hibernate.HibernateUtil;
import com.nagarro.Assignment3.model.Product;
import com.nagarro.Assignment3.model.User;

@SuppressWarnings("deprecation")
public class ProductDao {
	
	public static void SaveProduct(HttpServletRequest request, HttpServletResponse response,String imageUrl){
		HttpSession sessionuser =request.getSession();  
		String userName = (String) sessionuser.getAttribute("userName");
		String title = request.getParameter("title");
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		int size = Integer.parseInt(request.getParameter("size"));
		Product product = new Product();
		product.setTitle(title);
		product.setQuantity(quantity);
		product.setSize(size);
		product.setImglink(imageUrl);
		Session session = HibernateUtil.sf.openSession();
		session.beginTransaction();
		User user = (User) session.createQuery("FROM User WHERE userName = :username").setParameter("username", userName).uniqueResult();
		product.setUser(user);
		try {
			session.save(product);
			session.getTransaction().commit();
		}
		catch (Exception e) {
		 	session.getTransaction().rollback();
			session.close();
			System.out.println("Eception in SaveProduct Mehtod "+e);
			String msg = "Try use unique title ";
			request.setAttribute("msg", msg);
	 	}
		session.close();
	}
	
	public static List<Product> getProductList(HttpServletRequest request, HttpServletResponse response)
	{
		HttpSession sessionuser =request.getSession();  
		Session session =  HibernateUtil.sf.openSession();
		session.beginTransaction();
		String userName = (String) sessionuser.getAttribute("userName");
		User user = (User) session.createQuery("FROM User WHERE userName = :username").setParameter("username", userName).uniqueResult();
		int userId = user.getId();
		@SuppressWarnings("rawtypes")
		Query query = session.createQuery("from Product WHERE user_id = :userId").setParameter("userId", userId);
		@SuppressWarnings( "unchecked")
		List<Product> result = query.list();
		session.getTransaction().commit();
		session.close();
		return result;
	}
	
	public static void editProduct(HttpServletRequest request, HttpServletResponse response,String imageUrl)
	{
		int productId = Integer.parseInt(request.getParameter("Product"));
		String title = request.getParameter("title");
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		int size = Integer.parseInt(request.getParameter("size"));
		
		HttpSession sessionuser =request.getSession();  
		Session session =  HibernateUtil.sf.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Product WHERE id = :id").setParameter("id", productId);
		@SuppressWarnings( "unchecked")
		List<Product> result =  query.list();
		Product p = result.get(0);
		if(title != null)
			p.setTitle(title);
		
		if(quantity!=0)
			p.setQuantity(quantity);
		
		if(size != 0)
			p.setSize(size);
		
		if(imageUrl != null)
			p.setImglink(imageUrl);
		System.out.println(p.toString());
		try {
			session.saveOrUpdate(p);
			session.getTransaction().commit();
		}
		catch (Exception e) {
		 	session.getTransaction().rollback();
			session.close();
			String msg = "Try use unique title ";
			request.setAttribute("msg", msg);
			System.out.println("Eception in Edit Product Mehtod "+e);
	 	}
		session.close();
	
	}
	
	public static void deleteProduct(String id)
	{
		int productId = Integer.parseInt(id);
		Session session = HibernateUtil.sf.openSession();
		session.beginTransaction();
		Query query = session.createQuery("from Product Where id = :id").setParameter("id",productId);
		List<Product> result =  query.list();
		Product p = result.get(0);
		session.delete(p);
		session.getTransaction().commit();
		session.close();
	}
}
