package com.nagarro.Assignment3.dao;

import java.io.File;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

public class ImageDao {
	
	public static String SaveImage(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	{
		Part imagefile = request.getPart("file");
		if(imagefile.getSubmittedFileName()=="")
		{
			return null;
		}
		String imagePath = genratefileName();
		
		String uploadPath = "C:\\Users\\shobhitsharma\\eclipse-workspace\\Assignment3\\WebContent\\images\\"+ imagePath;
		try {           
			FileOutputStream fileOutput = new FileOutputStream(uploadPath);
			InputStream inputStream = imagefile.getInputStream();
			byte[] data = new byte[inputStream.available()];
			inputStream.read(data);
			fileOutput.write(data);
			fileOutput.close();
		} 
		catch (Exception e) {
			System.out.println("Exception in SaveImage :"+e);
		}
		return imagePath;
	}
	public static String genratefileName()
	{
		int min = 1000;
		int max = 100000;
		int filenum = (int)(Math.random()*(max-min+1)+min);  
		String fileName = Integer.toString(filenum)+".jpg";
		File file = new File("C:\\Users\\shobhitsharma\\eclipse-workspace\\Assignment3\\WebContent\\images"+fileName);
		while(file.exists())
		{
			filenum = (int)(Math.random()*(max-min+1)+min);  
			fileName = Integer.toString(filenum)+".jpg";
			file = new File("C:\\Users\\shobhitsharma\\eclipse-workspace\\Assignment3\\WebContent\\images"+fileName);
		}
		return fileName;
	}
}
