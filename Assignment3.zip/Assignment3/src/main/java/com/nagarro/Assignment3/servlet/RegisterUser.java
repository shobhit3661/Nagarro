package com.nagarro.Assignment3.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import com.nagarro.Assignment3.Hibernate.*;
import com.nagarro.Assignment3.model.Product;
import com.nagarro.Assignment3.model.User;

/**
 * Servlet implementation class RegisterUser
 */

//This api will regiester the user Into Data Base

@WebServlet("/RegisterUser")
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("Came in Save User");
		String userName  = request.getParameter("username");
		String pass  = request.getParameter("password");
		User user = new User();
		user.setPass(pass);
		user.setUserName(userName);
		user.setProductList(new ArrayList<Product>());
		Session session = HibernateUtil.sf.openSession();
		session.beginTransaction();
		try {
			session.save(user);
			session.getTransaction().commit();
		} catch (Exception e) {
			String msg = "User could not be saved !! Try using unique Username";
			request.setAttribute("msg", msg);
			RequestDispatcher dispatcher = request.getRequestDispatcher("register.jsp");
			dispatcher.forward(request, response);
			System.out.print(e);
			session.getTransaction().rollback();
			session.close();
			return ;
		}
		session.close();
		String msg = "Registered sucessfully you can login now";
		request.setAttribute("msg", msg);
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
	}
}
