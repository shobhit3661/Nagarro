package com.nagarro.Assignment3.model;

import javax.persistence.*;

@Entity
public class Product {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	int id ;
	@Column(unique=true)
	private String title;
	private int quantity;
	private int size;
	private String imglink;
	
	@ManyToOne
	User user;

	public Product() {
	}

	public Product(int id, String title, int quantity, int size, String imglink, User user) {
		super();
		this.id = id;
		
		this.title = title;
		this.quantity = quantity;
		this.size = size;
		this.imglink = imglink;
		this.user = user;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public String getImglink() {
		return imglink;
	}

	public void setImglink(String imglink) {
		this.imglink = imglink;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", title=" + title + ", quantity=" + quantity + ", size=" + size + ", imglink="
				+ imglink + "]";
	}
	
	
}
